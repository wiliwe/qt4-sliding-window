// Use Foundation's styles
$(document).foundation().foundation('abide', { 
    patterns: { screen_name: /^[^\s\[\]\/\\()~!?#$%^&*{|,;`@"<>+='}:]{3,20}$/ } 
});

//Newsletter form, powered by AutoPilot
window.Anywhere = function(a) {
    a || (a = {}); 
    var b = new XMLHttpRequest;
    return b.open("POST", "http://dncom.bislr.com/_aaam", !0), b.setRequestHeader("Content-Type", "application/json"), b.send(JSON.stringify(a))
}, window.AnywhereFS = function(a, b, c, d) {
    var e = function(a, b, c) {
            var d = document.createElement("input");
            d.setAttribute("type", "hidden"), d.setAttribute("name", b), d.setAttribute("value", c), a.appendChild(d)
        },
        f = document.getElementById(a);
    if (f) {
        e(f, "a_f", a), e(f, "a_a", b), e(f, "a_r", d), c && e(f, "a_fm", JSON.stringify(c));
        var g = -1 == document.getElementsByTagName("body")[0].innerHTML.search(/gravityforms.js/) ? "redirect" : "gravityforms";
        switch (g) {
        case "redirect":
            f.action = "http://dncom.bislr.com/_aafs";
            break;
        case "gravityforms":
            d ? (f.action = "http://dncom.bislr.com/_aafs", jQuery(f).submit(function() {
                setTimeout(function() {
                    window.location = d
                }, 3e3)
            })) : jQuery(document).bind("gform_confirmation_loaded", function() {
                f.action = "http://dncom.bislr.com/_aafs", jQuery(f).submit()
            });
            break;
        default:
            f.action = "http://dncom.bislr.com/_aafs"
        }
    } else console.log("Could not find form.")
}, Anywhere();
AnywhereFS('mailinglist_form', 'Newsletter', {
    'fullname': 'full_name',
    'email': 'email'
}, 'http://developer.nokia.com/site/confirmation');

                                 
// Run when DOM is ready
$(document).ready(function (){

	/** 
	*  ----------------------------------------
	*  Load profile image as FileReader object
	*  ----------------------------------------
	*/
	function fileUpload(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function (e) {
				var target = e.target || e.srcElement;
				$('#avatar').attr('src', e.target.result).css({
				   width : '200px',
				   height : '200px'
				});
			}
			reader.readAsDataURL(input.files[0]);
		}
	}
	$("#file-upload").change(function(){
		fileUpload(this);
	});
	
	/**
    *  ----------------------------------------
    *  Load Avatars
	*  ----------------------------------------
    */ 	   
    function loadAvatars(){
        var avatars = jQuery('img.avatar'),
            avatar = null;

        avatars.each(function(){
            avatar = jQuery(this);

            validateImgUrl(
                avatar,
                avatar.attr('data-avatar-src'),
                function(elImg, url){
                    elImg.attr('src', url);
                }
            );
        });
    };
    
    var base_url = document.location.protocol + '//' + document.location.host;

    /**
    *  -------------------------------------------
    *  AJAX retrieve data, FOR FAST BLOGS LISTINGS
	*  -------------------------------------------
    */
    $('#blogs-ajaxdata').each(function(i){
        var ajaxdata = $(this);
        var url = $(this).attr('data-url');
        if (url != null) {
            $.ajax({
                type: "POST",
                url: base_url + url,
                success: function(results){
                    ajaxdata.html(results); 
                },
                error: function(results){
                        window.console.log('error' + base_url + url + results) && console.log('error:' + base_url + url + results);
                }
            });
        } // if
    });

    /**
    *  ----------------------------------------
    *  AJAX retrieve data
	*  ----------------------------------------
    */
    $('.ajaxdata').each(function(i){
		var ajaxdata = $(this);
		var url = $(this).attr('data-url');
		if (url != null) {
			$.ajax({
			type: "POST",
			url: base_url + url,
			success: function(results){
				ajaxdata.html(results); 
			   
				// Events Page - Catalogue part
				 $('.postajax.catalogue-expandable').click(function(e){
					$(this).next().toggle();
					$(this).toggleClass('selectedHeaderBg');
					$(this).find('h3').toggleClass('selectedHeaderText');
					$(this).find('.icon-catalogue-right').toggleClass('rotate');
				});

				 $('.right-expandable').click(function(e){
					$(this).parents('.expandable').find('.expanded').toggle();
					$(this).toggleClass('selectedHeaderBg');
					$(this).find('h3').toggleClass('selectedHeaderText');
					$(this).find('.icon-schedule-right').toggleClass('rotate');
				});
				 
				$("form.validate").attr("data-abide", "");
				$(document).foundation('abide','events');
				$(document).foundation('');

                abideCheckboxFix();
                abideEmailConfirmFix();
                sidebarTabs();
                loadAvatars();
                pageFeedback();

				// XID refresh code 
				$("form").on('click', function (){
					refreshXID($(this));
				});
				
				// Submit "processing", confirmation-like pages 
				// Since these might be cached, must refresh the XID first
				// and do it without needing user to click anything.				
				if($("form.backgroundsubmit"))
				{
					refreshXID($("form.backgroundsubmit"));
				}
			},
			error: function(results){
					window.console.log('error' + base_url + url + results) && console.log('error:' + base_url + url + results);
			}
		 });
		} // if
    }); 	

    abideCheckboxFix();
    abideEmailConfirmFix();
    sidebarTabs();
    loadAvatars();
    pageFeedback();

    /**
     * -----------------------------------------------------------
     * Abide Email Confirmation Fix
     * Used to check if "email" and "email_confirm"
     * fields have the same content. A small.email_confirm
     * error element can be used to display an error about this.
     * Only works on fields "email" and "email_confirm", as a pair
     * -----------------------------------------------------------
     */
    function abideEmailConfirmFix(){

        $("form[data-abide]").on('submit', function(e) {

            emailField = $(this).find("input[name='email']");
            emailConfirmField = $(this).find("input[name='email_confirm']");

            if(emailField.length != 0 && emailConfirmField.length != 0)
            {
                if(emailField.val() != emailConfirmField.val())
                {
                    $(this).find('small.email_confirm').show();
                    e.preventDefault();
                }
            }
        });

        /**
		* ------------------------------------------------------------
        * Displays or hides the confirm email error message
        * Once the user moves away (blur) from the email_confirm field
		* ------------------------------------------------------------
        */
        $("form[data-abide] input[name='email_confirm']").on('blur', function(e) {

            emailField = $(this).closest("form[data-abide]").find("input[name='email']");
            emailConfirmField = $(this).closest("form[data-abide]").find("input[name='email_confirm']");

            if(emailField.length != 0 && emailConfirmField.length != 0)
            {
                if(emailField.val() == emailConfirmField.val())
                {
                    $(this).closest("form[data-abide]").find('small.email_confirm').hide();
                }

                if(emailField.val() != emailConfirmField.val())
                {
                    $(this).closest("form[data-abide]").find('small.email_confirm').show();
                }
            }
        });
    }
    
    
    /**
     * ----------------------------------------
     * Abide Checkbox Fix
     * Required checkbox error highlighting,
     * since Foundation doesn't do this right.
     * ----------------------------------------
     */
    function abideCheckboxFix(){
        
        // ----------------------------------------
        // The following checks, on submit button click:
        // 1. If there are checkbox groups
        // 2. If there are required checkbox fields
        // 3. If there is 1 or more checkboxes checked
        // 
        // When there are checkboxes that are not checkbox groups, the script checks:
        // 1. If the single checkbox field is required
        // 2. If the single checkbox checked.
        // ----------------------------------------
        $("form[data-abide]").on('submit', function(e) {

            formCheckboxes = $("form[data-abide] label input[type=checkbox][required]");

            formCheckboxes.each(function(index){

                fieldName = $(this).attr("name");

                // ----------------------------------------
                // Check if this is a checkbox group, 
                // then add or remove error class on label
                // ----------------------------------------
                if($("input[name='"+fieldName+"'][required]").length > 1)
                {   
                    // Clean up fieldName to remove brackets, eg. string coming from name="variable[node][]"
                    // The cleaned fieldName should be the error element's class. 
                    cleanedFieldName = fieldName.replace(/[\[\]]+/g, '');

                    // ----------------------------------------
                    // Check if there's at least one checkbox checked.
                    // ----------------------------------------
                    if( $("input[name='"+fieldName+"'][required]:checked").length >= 1)
                    {
                        $("small."+cleanedFieldName).hide();
                    }
                    else
                    {
                        $("small."+cleanedFieldName).show();
                        e.preventDefault();
                    }
 
                }
                // ----------------------------------------
                // Single checkboxes
                // ----------------------------------------
                else
                {
                    if( ! $(this).is(":checked"))
                    {
                        $(this).closest("label").addClass("error");
                        $(this).closest("label").find("span.form-error").show();
                        e.preventDefault();
                    }
                    else
                    {
                        $(this).closest("label").removeClass("error");
                        $(this).closest("label").find("span.form-error").hide();
                    }
                }
                
            });
        });

        // ----------------------------------------
        // Once a checkbox group is marked with error classes
        // Remove the error classes once a checkbox is clicked 
        // ----------------------------------------
        $("form[data-abide] span.checkbox").on('click', function(e) {

            fieldName = $(this).prev("input[type=checkbox][required]").attr("name");

            // Clean up fieldName to remove brackets, eg. string coming from name="variable[node][]"
            // The cleaned fieldName should be the error element's class. 
            cleanedFieldName = fieldName.replace(/[\[\]]+/g, '');console.log(cleanedFieldName);

            // ----------------------------------------
            // Check if this is a checkbox group, 
            // ----------------------------------------
            if($("input[name='"+fieldName+"'][required]").length > 1)
            {
                // The length calculation happens before the input field
                // is actually checked yet, so adjust by adding 1 to length
                if( $("input[name='"+fieldName+"'][required]:checked").length + 1 >= 1)
                {
                    $("small."+cleanedFieldName).hide();
                }
            }
        });
    }
	

    /**
    *  ----------------------------------------
    *  Refresh XID
    *  ----------------------------------------
    */
    function refreshXID(theForm)
    {
        if(theForm.find("input[name=XID]").length > 0 && theForm.find("input[name=XID]").attr("data-fresh_xid") === undefined)
        {
            $.ajax({
				type: "POST",
				url: base_url + '/?ACT=69&which=fetch_xid',
				success: function(results){
						theForm.find("input[name=XID]").val(results).attr("data-fresh_xid", "");

                        if($("form.ajaxparams").length > 0)
                        {
                            params_id = $("form.ajaxparams").find("input[name=params_id]").val();
                            theForm.find("input[name=params_id]").val(params_id);                        
                        }
						
						/** 
						 * Submit "processing", confirmation-like pages 
						 * Do it without needing user to click anything.
						 */
						if($("form.backgroundsubmit"))
						{    
							$("form.backgroundsubmit").find("input[type=submit]").click();
						}
					},
				error: function(results){
						window.console.log(results) && console.log(results);
				}
            });
        }
    } // function refreshXID()    

    /**
    *  ---------------------------------------------------
    *  Validate Image URL
    *  Check to see if an image actually exists for a URL
	*  ---------------------------------------------------
    */  

    function validateImgUrl(elImg, url, successCallback, errorCallback){
        var img = new Image();
        img.onload = function() {
            if (typeof successCallback !== 'undefined') {
                successCallback(elImg, url);
            }
        };
        img.onerror = function() {
            if (typeof errorCallback !== 'undefined') {
                errorCallback(elImg, url);
            }
        };

        img.src = url
    };

    /**
    *  ----------------------------------------
    *  Profile edit / Terms
	*  ----------------------------------------
    */	
    if (typeof select2 == "function")
    {
    	$("#country").select2();
    	$("#nearestCity").select2({
    		minimumInputLength: 3,
    		initSelection : function (element, callback) {
    			var data = {id: element.val(), text: $('#nearestCityName').val()};
    			callback(data);
    		},
    		query: function(query) {
    			$.ajax({
    				url: '/search/cities/' + query.term + '/' + $('#country').val(),
    				dataType: 'json',
    				type: 'GET',
    				success: function(data) {
    					query.callback({
    						results: data
    					});
    				}
    			})
    		}
    	});
    }

    /**
    *  ------------------------------------------
    *  Sidebar menu expand/collapse functionality
	*  ------------------------------------------
    */
    $("ul.sidebar-items a.expandcollapse").click( function(event) {

        event.preventDefault();

        if( $(this).find("i").hasClass('fa-angle-down') == true )
        {
            // Close
            //console.log("close");
            $(this).closest("ul").removeClass('itemsExpanded');
            $(this).closest("li").children("ul").slideToggle();
            $(this).find("i").removeClass("fa-angle-down").addClass("fa-angle-right");
        } else {
            // Open
            //console.log("open");
            $(this).closest("ul").addClass('itemsExpanded');
            $(this).closest("li").children("ul").slideToggle();
            $(this).find("i").removeClass("fa-angle-right").addClass("fa-angle-down");
        }
    });

    /**
    * ---------------------------------------------------------------------------------------------------
	* Go through each li element in the sidebar and check if it
    * has any children li elements. If not, remove the arrow.
    * This is needed if you have a single child entry under a parent entry, but the child entry is closed. 
    * Without this, the parent entry would have an arrow but no visible child entries.
	* ---------------------------------------------------------------------------------------------------
    */
    $("ul.sidebar-items li").each(function(){
        if($(this).find("li").length == 0)
        {
            $(this).find("a.expandcollapse").remove();
        }
    });

    /**
    * -----------------------------------------------------------------------------------------
	* Traversing to show all links above and below the active link, within the current section
	* -----------------------------------------------------------------------------------------
    */
    $("ul.sidebar-items").find("li.active").parents("ul").show();
    $("ul.sidebar-items").find("li.active").children("ul").show();
    $("ul.sidebar-items").find("li.active").children("div").children("a.expandcollapse").children("i").removeClass("fa-angle-right").addClass("fa-angle-down");
    
    $("ul.sidebar-items").find("a.active").parents("ul").show();
    $("ul.sidebar-items").find("a.active").closest("li").children("ul").show();
    $("ul.sidebar-items").find("a.active").siblings("a.expandcollapse").children("i").removeClass("fa-angle-right").addClass("fa-angle-down");
    

    /**
    *  ----------------------------------------
    *  Sidebar - filtering displayed content
    *  ----------------------------------------
    */
    function sidebarTabs(){
        var links = $('.sub-nav dd a');
        var filter_crit = $('.sub-nav dd a.filter');
        var show_all = $('.sub-nav dd a.show_all');
        var divs = $('.items div.feed-item');
        $('a.show_all').parent().addClass('active');

        // Add/remove .active class to highlight dd
        links.click(function(event){
            $('.active').removeClass('active');
            $(this).parent().addClass('active');
        });

        // Filter divs based on id
        filter_crit.click(function(event){
           divs.hide();
           divs.filter('.' + event.target.id).show();
        });

        // Show all feed items
        show_all.click(function(event){
            divs.show();
        });       
    } // end sidebarTabs
	
	/**
    *  ----------------------------------------------
    *  Generic function - filtering displayed content
    *  ----------------------------------------------
    */	
	//1st drop-down
	$(function(){
		$('#dropDown1').change(function(){
			$('.dd_filter1').hide();
			$('#' + this.value).show();
		});
		
		//2nd drop-down
		$('#dropDown2').change(function(){
			$('.dd_filter2').hide();
			$('#' + this.value).show();
		});
	});
	
	/**
    *  ----------------------------------------------
    *  Page rating & feedback
    *  ----------------------------------------------
    */	
	function pageFeedback()
	{
		$('#fbk_step2').hide();
		$('#fbk_step3').hide();

		$('#fbk_step1 #btn_yes').on('click', function(){
			$('input#yes_no').val('Yes');
		});
		$('#fbk_step1 #btn_no').on('click', function(){
			$('input#yes_no').val('No');
		});
		$('#fbk_step1 .button').click(function() {
			$("#fbk_step2").show();
			$("#fbk_step1").replaceWith($("#fbk_step2"));
		});
		$('#page_fbk').on('submit', function(e){
			$.post(
				$(this).attr('action'),
				$(this).serialize(),

				function(){
					$("#fbk_step3").show();
					$("#fbk_step2").replaceWith($("#fbk_step3"));
				} // function data
			); // post
			e.preventDefault();
		});
	}; // function pageFeedback
	
    /**
    *  ----------------------------------------
    *  Devices landing page - reveal/hide modal
    *  ----------------------------------------
    */
    $('.device, .reveal').click(function(){
        $(this).find('.reveal-modal').foundation('reveal', 'open');
    });
    //  -----------------------------------------------


    /**
    *  ----------------------------------------
    *  Generic details expand/collapse functionality
    *  ----------------------------------------
    */
    $(function(){
        // One panel
        $('.nokia-expandable section .title').click(function(e){
            $(this).parent('section').toggleClass('active');
            $(this).toggleClass('exp');
        });

        // All panels
        $('#expandAll').click(function(e){
            $('.nokia-expandable section').addClass("active");
            $('.nokia-expandable section .title').addClass('exp');
        });
        $('#collapseAll').click(function(e){
            $(".nokia-expandable section").removeClass("active");
            $('.nokia-expandable section .title').removeClass('exp');
        });
    });
    //  -----------------------------------------------
	
	/**
    *  ----------------------------------------
    *  Events & webinars expand/collapse functionality
    *  ----------------------------------------
    */
    $(function(){
        // Top schedule part
        $('.right-expandable').click(function(e){
            $(this).parents('.expandable').find('.expanded').toggle();
            $(this).toggleClass('selectedHeaderBg');
            $(this).find('h3').toggleClass('selectedHeaderText');
            $(this).find('.icon-schedule-right').toggleClass('rotate');
        });
		
        // Catalogue part
         $('.catalogue-expandable').click(function(e){
            $(this).next().toggle();
            $(this).toggleClass('selectedHeaderBg');
            $(this).find('h3').toggleClass('selectedHeaderText');
            $(this).find('.icon-catalogue-right').toggleClass('rotate');
        });		
		
    });
    //  -----------------------------------------------


    /**
    *  ----------------------------------------
    *  Downloads landing page - search
    *  ----------------------------------------
    */
    $(function(){
        $('.downloads select#dl_type, .downloads select#dl_platform').change(function(){
            var url = '/resources/downloads/search';
            if ($('.downloads select#dl_type').length > 0 && $('.downloads select#dl_type').val() != '')
            {
                url = url + '&cf_download_type=' + $('.downloads select#dl_type').val();
            }
            if ($('.downloads select#dl_platform').length > 0 && $('.downloads select#dl_platform').val() != '')
            {
                url = url + '&category=' + $('.downloads select#dl_platform').val();
            }
            window.location.href    = url;
        });
    });


    /**
    *  ----------------------------------------
    *  Downloads detail page - eula
    *  ----------------------------------------
    */
    $(function(){
        $('.downloads form#dl_eula_form').submit(function(){
            $('.downloads input#dl_accept_eula').closest('label').removeClass('error');
            $('.downloads #dl_eula_error').hide();
            if ($('.downloads input#dl_accept_eula:checked').length == 0){
                $('.downloads input#dl_accept_eula').closest('label').addClass('error');
                $('.downloads #dl_eula_error').show();
                return false;
            }
        });
    });
	
    /**
    *  ----------------------------------------
    *  Downloads add clicky if SDK
    */
    var  dnloadTitle = $('#downloadtitle').text().toLowerCase();
    if ( dnloadTitle.indexOf('nokia x') >= 0 && dnloadTitle.indexOf('sdk') >= 0 ) {
        $('#clickylog').addClass('clicky_log_download');
    }

	
    /**
    *  ----------------------------------------
    *  Device landing page 
    *  ----------------------------------------
    */
    $(function(){
		$("form#devicefilter select#customDropdown1").change(function() {
			var url = '/devices/searchresults/search';
			if ($(this).val() != '')
			{
				url = url + '&keywords=' + $(this).val();
			
				if ($("form#devicefilter input[name='search_in']").length > 0 && $("form#devicefilter input[name='search_in']").val() != '')
				{
					url = url + '&search_in=' + $("form#devicefilter input[name='search_in']").val();
				}
			}
			window.location.href    = url;
		});
    });
    

	/**
    *  ----------------------------------------
    * Resource pages
    *  ----------------------------------------
    */
    $(function(){
		$('form#resourcefilter select#platform, form#resourcefilter select#downloadlevel').change(function() {
			var url = $.trim($('form#resourcefilter').attr('action'));
			if (url.indexOf("/search&") != -1){
				url = url.substring(0, url.indexOf("/search&"));
			}
			url	= url + '/search';
            if ($('form#resourcefilter select#platform').length > 0 && $('form#resourcefilter select#platform').val() != '')
            {
                url = url + '&category=' + $('form#resourcefilter select#platform').val();
            }
            if ($('form#resourcefilter select#downloadlevel').length > 0 && $('form#resourcefilter select#downloadlevel').val() != '')
            {
            	var name = $('form#resourcefilter select#downloadlevel').attr('name');
                url = url + '&' + name + '=' + $('form#resourcefilter select#downloadlevel').val();
            }
			window.location.href    = url;
		});
    });
    

    /**
    *  ----------------------------------------
    *  The submit buttonless form
    *  ----------------------------------------
    */
    $("form.searchform select").change(function (event) {
        $(this).closest("form").submit();
    });

	/**
    *  ----------------------------------------
    *  Search
    *  ----------------------------------------
    */	
    $(function(){
        $('#search-form input[type=submit]').on('click', function(e){
            e.preventDefault();
            var url = '/search/results' + '/search&channel=web' + '&limit=20';
            var inputsearch = $('#search-form input#search');
            var category = $('#search-form input:checked.search-category'); 
			
			var pattern = /[<>\[\]#&$*`^;{}()]+/;	
			
            if (inputsearch.length > 0 && inputsearch.val() != '' && pattern.test(inputsearch.val())) {
				$('#search-form span.form-error').remove();
                $('#search-form').append('<span class="form-error">Your search contains disallowed characters.</span>');
                $('.results').empty();
                $("span.search_keywords").html(inputsearch.val());
				return false;
            }	
			
			else if (inputsearch.length > 0 && inputsearch.val() != '') {
                var keywords = inputsearch.val().replace(/ /g, '+');
                keywords =  keywords.replace(/%/g, '');
                if ( category.val() == '' ) category = 'all';
                url = url + '&keywords=' + keywords + '&category=' + category.val()  + '/';
            }	
				
			else {
				$('#search-form span.form-error').remove();
                $('#search-form').append('<span class="form-error">Please enter search keywords.</span>');
                $('.results').empty();
                $("span.search_keywords").html(inputsearch.val());
				return false;				
			}
            window.location.href = url;
        });
    });	
	
                                            
    /**
    *  ----------------------------------------
    *  XID refresh
    *  Fetches a fresh XID when interacting with a form
    *  ----------------------------------------
    */
   $("form").on('click', function (){
        refreshXID($(this));
   });

	/**
	*  ----------------------------------------
	*  Add Page's Title to Social Media Sidebar links
	*  ----------------------------------------
	*/
	var title = document.title.replace("| Developer News | Nokia Developer", "");
	title = title.replace("| Community Blog | Nokia Developer", "");
	title = title.replace("| Code Blog | Nokia Developer", "");
	var metatitle = encodeURIComponent(title);
	var twlink = $('#share-tw').attr('href');
	var lilink = $('#share-li').attr('href');
	$('#share-tw').attr("href", twlink + '&text=' + metatitle);
	$('#share-li').attr("href", lilink + '&title=' + metatitle);
   
   /**
    *  ----------------------------------------
    *  Responsive Tables by Zurb
    *  ----------------------------------------
    */
	var switched = false;	
	var updateTables = function() {
		if (($(window).width() < 767) && !switched ){
			switched = true;
			$("table.responsive").each(function(i, element) {
				splitTable($(element));				
			});
			return true;
		}
		else if (switched && ($(window).width() > 767)) {
			switched = false;
			$("table.responsive").each(function(i, element) {
				unsplitTable($(element));
			});
		}
	};
   
	$(window).load(updateTables);
	$(window).on("redraw",function(){switched=false;updateTables();}); // An event to listen for
	$(window).on("resize", updateTables);   
	
	function splitTable(original)
	{
		original.wrap("<div class='table-wrapper' />");
		
		var copy = original.clone();
		copy.find("td:not(:first-child), th:not(:first-child)").css("display", "none");
		copy.removeClass("responsive");
		
		original.closest(".table-wrapper").append(copy);
		copy.wrap("<div class='pinned' />");
		original.wrap("<div class='scrollable' />");

    setCellHeights(original, copy);
	}
	
	function unsplitTable(original) {
    original.closest(".table-wrapper").find(".pinned").remove();
    original.unwrap();
    original.unwrap();
	}

  function setCellHeights(original, copy) {
    var tr = original.find('tr'),
        tr_copy = copy.find('tr'),
        heights = [];

    tr.each(function (index) {
		var self = $(this),
        tx = self.find('th, td');

		tx.each(function () {
			var height = $(this).outerHeight(true);
			heights[index] = heights[index] || 0;
			if (height > heights[index]) heights[index] = height;
		});
    });

    tr_copy.each(function (index) {
		$(this).height(heights[index]);
    });
  } //end of Responsive Tables

}); //end